# Catatan
Pada folder ini tidak ada file `google-service.json` untuk konfigurasi Firebase dan `local.properties` untuk API Key Google Maps.

Bisa buka link di bawah ini untuk membantu konfigurasi:
- https://firebase.google.com/docs/android/setup untuk konfigurasi Firebase.
- https://developers.google.com/maps/documentation/android-sdk/config untuk konfigurasi Google Maps.
