package com.septovan.pam.fragment;

public class ArticleModel {
    static String[] articleTitle = {
            "Judul 1",
            "Judul 2"
    };

    static String[] articleBody = {
            "Judul 1\n\nArticle Body 1",
            "Judul 2\n\nArticle Body 2"
    };
}
