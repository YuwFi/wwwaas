# [Expo](https://expo.dev/)
1. Silahkan membuat akun Expo.
2. Silahkan ikuti proses instalasi Expo di komputer Anda > https://docs.expo.dev/get-started/installation/. | Note: Jika kalian mendapati error **"expo.ps1 cannot be loaded because running scripts is disabled on this system"**, ikuti solusi ini > https://dev.to/osmanforhad/expo-ps1-cannot-be-loaded-because-running-scripts-is-disabled-on-this-system-5h81
3. Silahkan ikuti tutorial ini untuk membuat aplikasi pertama > https://docs.expo.dev/get-started/create-a-new-app/.

# Happy exploring!
[Dokumentasi Expo](https://docs.expo.dev/)
