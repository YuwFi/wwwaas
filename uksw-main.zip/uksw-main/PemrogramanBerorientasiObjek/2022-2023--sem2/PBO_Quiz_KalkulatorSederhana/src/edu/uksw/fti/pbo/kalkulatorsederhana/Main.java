package edu.uksw.fti.pbo.kalkulatorsederhana;

public class Main {
    public static void main(String[] args) {
        int angka1 = 10, angka2 = 7;

        int hasilJumlah = angka1 + angka2;

        System.out.println("angka1 + angka2 = " + (hasilJumlah));
        System.out.println("angka1 - angka2 = " + (angka1 - angka2));
        System.out.println("angka1 * angka2 = " + (angka1 * angka2));
        System.out.println("angka1 / angka2 = " + (double)((double)angka1 / (double)angka2));
        System.out.println("angka1 % angka2 = " + (angka1 % angka2));
    }
}
