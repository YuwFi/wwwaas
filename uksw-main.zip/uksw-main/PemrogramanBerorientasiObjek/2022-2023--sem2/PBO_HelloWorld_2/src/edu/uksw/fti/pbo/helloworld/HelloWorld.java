package edu.uksw.fti.pbo.helloworld;

public class HelloWorld {

    public static void main(String[] args) {
        String nama = "Septovan";
        String nim = "672015027";
        int umur = 17;

        System.out.println("Nama saya " + nama + " dengan NIM " + nim);
        System.out.println("Umur saya " + umur);
    }

}
