/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pl_helloworld;

/**
 *
 * @author Septovan D. S. Saian
 */
public class AvanzaG13 {
    int rodaEmpat = 0;
    int pintu = 0;       
    
    void cetakRoda() {
        System.out.println("Roda 4");
    }
    
    void cetakRoda(int roda) {
        System.out.println("Roda " + roda);
    }
    
    void cetakRoda(String velg) {
        System.out.println("Velgnya adalah " + velg);
    }
}
