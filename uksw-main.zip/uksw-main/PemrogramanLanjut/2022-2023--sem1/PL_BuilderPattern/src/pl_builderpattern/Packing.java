/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package pl_builderpattern;

/**
 *
 * @author Septovan D. S. Saian
 */
public interface Packing {
    public String pack();
}
