package com.fti.pl.PLSpringBootHibernate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlSpringBootHibernateApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlSpringBootHibernateApplication.class, args);
	}

}
