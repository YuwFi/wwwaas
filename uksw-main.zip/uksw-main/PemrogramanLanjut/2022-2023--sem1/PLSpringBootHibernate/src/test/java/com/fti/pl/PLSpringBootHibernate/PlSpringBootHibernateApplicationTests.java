package com.fti.pl.PLSpringBootHibernate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlSpringBootHibernateApplicationTests {

	@Test
	void contextLoads() {
	}

}
