# UKSW
Sebuah repository untuk menyimpan source code dari latihan-latihan yang diterangkan dalam perkuliahan.<br/>
Materi (PPT) dan recording perkuliahan bisa ditemukan di [FLEARN](https://flearn.uksw.edu/) atau Google Classroom.

## Catatan
Silahkan masuk ke dalam folder yang sesuai dengan mata kuliah.
